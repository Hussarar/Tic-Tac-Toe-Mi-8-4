Zum kompilieren in dem src-Ordner mit der Kommandozeile den Befehl "make" ausführen (gcc bzw. mingw und make muss vorher per Packet Manager installiert werden!)

Wenn beim Programmstart eine Fehlermeldung mit "Programm passt nicht in die Fenstergroesse!" erscheint:

Rechtsklick beim Programm auf den Fensterrahmen oben. Wähle Eigenschaften -> Layout -> Unter Fenstergröße die Breite und Höhe ändern
Anschließend das Programm neustarten.
Wichtig: Breite sollte das dreifache der Höhe sein und die Höhe muss über ca. 30 sein!


ANLEITUNG ZUM SPIELEN

Startmenü:

Pfeiltaste Hoch und Runter zum steuern.
Enter um den Modus zu bestätigen.

Farbeinstellungen:
Pfeiltaste Hoch und Runter zum steuern.
Mit Enter bestätigen.

Spielfeld aufbau:

    |     |  
----|-----|-----
    |     |  
----|-----|-----
    |     |  

Pfeiltasten benutzen um Feld auszuwählen. Mit Enter bestätigen.


CREDITS

Code für die Funktion den Kreis zu erstellen: Bresenham's circle drawing algorithm
Link: https://www.geeksforgeeks.org/bresenhams-circle-drawing-algorithm/

Code für Schweren Computerspieler: The Coding Train "Coding Challenge 154: Tic Tac Toe AI with Minimax Algorithm"
Link: https://www.youtube.com/watch?v=trKjYdBASyQ

Code für die makefile:
https://www.cs.colby.edu/maxwell/courses/tutorials/maketutor/

Gruppe: "Mi-8Uhr-4 ,Tic Tac Toe"

Ye, Cheng-Fu
Schwabe, Dominik
Griessel, Patrick
Adler, Matthias