#ifndef GAMEVISUALS_H
#define GAMEVISUALS_H

void gamearena();

void printx(int a, int b);

void printo(int a, int b);

int checkWindowSize();

int choose_field();

int startmenu();

void loadboard(char arr[3][3]);

#endif