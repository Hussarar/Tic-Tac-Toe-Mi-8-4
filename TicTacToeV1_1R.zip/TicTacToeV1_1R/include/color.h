#ifndef COLOR_H
#define COLOR_H

int get_color();

void init_colors();

void display_options();

int color_menu();

void settings_print(int colornum);

void start_color_options();

#endif